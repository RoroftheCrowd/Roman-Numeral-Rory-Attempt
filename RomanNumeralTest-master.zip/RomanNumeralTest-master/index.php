<?php
namespace PhpNwSykes;
require_once __DIR__ . DIRECTORY_SEPARATOR . "vendor" . DIRECTORY_SEPARATOR . "autoload.php";

$positiveTests = [
    'X' => 10,
    'IX' => 9,
    'V' => 5,
    'MMX' => 2010,
];

$negativeTests = [
    'Bad',
    'XI Something',
    'Something MM',
    '-X',
];

?>
<h2>Valid Tests</h2>
<?php
foreach ($positiveTests as $numerial => $expected) {
    printf('<p>%s should be %s - Result %s</p>', $numerial, $expected, ((new RomanNumeral($numerial))->toInt() === $expected) ? 'PASS' : 'FAIL');
}
?>
<h2>Invalid Tests</h2>
<?php
foreach($negativeTests as $numerial) {
    $exception = false;
    try {
        (new RomanNumeral($numerial))->toInt(); 
    } catch (\Exception $e) {
        $exception = true;
    }

    printf('<p>%s should throw exception - Result %s</p>', $numerial, $exception ? 'PASS' : 'FAIL');
}
?>
<?php
namespace PhpNwSykes;
class RomanNumeral
{
    protected $symbols = [
        1000 => 'M',
        500 => 'D',
        100 => 'C',
        50 => 'L',
        10 => 'X',
        5 => 'V',
        1 => 'I',
    ];
    protected $numeral;
    public function __construct(string $romanNumeral)
    {
        $this->numeral = $romanNumeral;
    }
    /**
     * Converts a roman numeral such as 'X' to a number, 10
     *
     * @throws InvalidNumeral on failure (when a numeral is invalid)
     */
    public function toInt():int
    {
        $total = 0;
        return $total;
    }
}
?>

<?php
/**Valid Numbers**/
namespace PhpNwSykes\Tests;

use PhpNwSykes\RomanNumeral;
use PHPUnit\Framework\TestCase;

class ValidNumeralsTest extends TestCase
{
    /**
     * @param $numeral The numeral to convert
     * @param $expected Expected output
     * @dataProvider numeralMapping
     */
    public function testValidInput($numeral, $expected)
    {
        $roman = new RomanNumeral($numeral);
        $this->assertSame($expected, $roman->toInt());
    }

    public function numeralMapping()
    {
        return [
            ['X', 10],
            ['IX', 9],
            ['V', 5],
            ['MMX', 2010],
        ];
    }

    public function testDoubleParse()
    {
        $roman = new RomanNumeral('MX');
        $this->assertSame(1010, $roman->toInt());
        $this->assertSame(1010, $roman->toInt());
    }
}?>

<?php
/** Invalid Numbers**/
namespace PhpNwSykes\Tests;

use PhpNwSykes\InvalidNumeral;
use PhpNwSykes\RomanNumeral;
use PHPUnit\Framework\TestCase;

class InvalidNumeralsTest extends TestCase
{
    /**
     * @param $numeral
     * @dataProvider badMappings
     */
    public function testInvalidOutput($numeral)
    {
        $this->expectException(InvalidNumeral::class);
        $roman = new RomanNumeral($numeral);
        $roman->toInt();
    }

    public function badMappings(): array
    {
        return [
            ['Bad'],
            ['XI Something'],
            ['Something MM'],
            ['-X'],
        ];
    }
}
?>

