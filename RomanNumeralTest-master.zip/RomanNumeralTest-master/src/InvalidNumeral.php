<?php
namespace PhpNwSykes;

use Exception;

class InvalidNumeral extends Exception
{
}
